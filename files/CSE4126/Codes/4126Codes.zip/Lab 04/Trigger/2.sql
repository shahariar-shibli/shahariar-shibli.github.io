clear screen;
drop table money1;

create table money1(id number, name varchar2(20), taka number);

select * from money1;
