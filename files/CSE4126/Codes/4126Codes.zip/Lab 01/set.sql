select id,name from money
union
select id,name from money1;