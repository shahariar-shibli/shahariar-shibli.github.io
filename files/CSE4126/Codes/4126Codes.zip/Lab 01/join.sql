select S.name, B.taka
from money S inner join money1 B
on S.id = B.id;

-- right join, left join